% TODO: 1) improve precision of logBesseli; 2) test cases for all functions
