function K = knLin(X, Y)
% Linear kernel (inner product)
K = X'*Y;

