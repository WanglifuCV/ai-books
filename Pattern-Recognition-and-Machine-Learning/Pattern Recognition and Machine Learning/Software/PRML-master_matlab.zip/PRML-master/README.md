Pattern Recognition and Machine Learning
===========

This package contains the matlab implementation of the algorithms described in the book Pattern Recognition and Machine Learning by C. Bishop.

see http://research.microsoft.com/en-us/um/people/cmbishop/prml/

License
-------
Currently Released Under GPLv3


Contact
-------
sth4nth at gmail dot com

