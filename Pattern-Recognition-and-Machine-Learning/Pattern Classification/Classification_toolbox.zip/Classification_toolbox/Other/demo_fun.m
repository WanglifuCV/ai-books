function y = demo(x)

y = -exp(-x.^2);
